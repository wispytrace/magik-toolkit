#!/usr/bin/python3
##        (C) COPYRIGHT Ingenic Limited.
##             ALL RIGHTS RESERVED
##
## File       : magik_executor_plugin.py
## Authors    : lqwang
## Create Time: 2022-03-16:09:39:32
## Description:
## 
##

import os
import logging
import numpy as np
import magik_executor.magik_executor_plugin as mep

class MagikRoutine:
    def __init__(self, mgk_path, dump_file=False):
        self._engine = mep.MagikRoutine(mgk_path)
        self._itensors = []
        self._inames = self._engine.inames()
        self._onames = self._engine.onames()
        if dump_file:
            if not os.path.exists('./MAGIK_DATA_DUMP'):
                os.makedirs('./MAGIK_DATA_DUMP')
            os.environ['MAGIK_CPP_DUMPDATA'] = 'true'
        elif not dump_file:
            os.environ['MAGIK_CPP_DUMPDATA'] = 'false'

    def inames(self):
        return self._inames

    def onames(self):
        return self._onames

    def run(self, __from=[], __to=""):
        if len(self._itensors) == 1:
            self._engine.setInput(self._itensors[0])
        elif len(self._itensors) > 1:
            self._engine.setInputs(self._itensors)
        else :
            logging.error("There is no input for magik routine, Please check it!")
            exit()
        self._engine.work(__from, __to)
        
    def set_input(self, arrary, name):
        if not arrary.flags['C_CONTIGUOUS']:
            arrary = np.ascontiguousarray(arrary, dtype=arrary.dtype)
        _itensor = mep.MagikTensor()
        __shape = list(arrary.shape)
        _itensor.setData(__shape, arrary.astype(np.float32))
        _itensor.setName(name)
        self._itensors.append(_itensor)

    def get_output(self, name):
        return self._engine.get_otensor(name)
