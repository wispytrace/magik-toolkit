#!/usr/bin/python3
##        (C) COPYRIGHT Ingenic Limited.
##             ALL RIGHTS RESERVED
##
## File       : __init__.py
## Authors    : lqwang
## Create Time: 2022-03-16:09:39:01
## Description:
## 
##

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from magik_executor import *

del absolute_import
del division
del print_function
