# -*- coding: utf-8 -*-
"""
    > File Name: __init__.py
    > Author: Magik Development Team
    > Created Time: Thu 02 Jan 2020 09:10:13 PM CST
    > Description:
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from ingenic_magik_trainingkit.QuantizationTrainingPlugin.python import ops
from ingenic_magik_trainingkit.QuantizationTrainingPlugin.python import quantize_ops

del absolute_import
del division
del print_function
