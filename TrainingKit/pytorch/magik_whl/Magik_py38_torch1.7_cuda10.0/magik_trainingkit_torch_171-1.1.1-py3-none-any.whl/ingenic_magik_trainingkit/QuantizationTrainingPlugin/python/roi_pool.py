# -*- coding: utf-8 -*-
"""
    > File Name: roi_pool.py
    > Author: Magik Development Team
    > Created Time: Tue 09 Nov 2021 03:52:41 PM CST
    > Description:
"""

import torch
import argparse
import math
import numpy as np
from torch.nn.parameter import Parameter
from torch.nn import init

from ingenic_magik_trainingkit.QuantizationTrainingPlugin.python.quantize_ops import *

class roi_pool(Function):
    @staticmethod
    @parse_args('v', 'v', 'v', 'f')
    def symbolic(g, input, rois, output_size, spatial_scale):
        return g.op(
            'MaxRoiPool',
            input,
            rois,
            pooled_shape_i=output_size,
            spatial_scale_f=spatial_scale)

    @staticmethod
    def forward(ctx, input, rois, output_size, spatial_scale=1.0):
        ctx.output_size = output_size
        ctx.spatial_scale = spatial_scale
        ctx.input_shape = input.size()

        assert rois.size(1) == 5, 'RoI must be (idx, x1, y1, x2, y2)!'

        output_shape = (rois.size(0), input.size(1), ctx.output_size[0],
                        ctx.output_size[1])
        output = input.new_zeros(output_shape)
        argmax = input.new_zeros(output_shape, dtype=torch.int)

        imtk_qtp.roi_pooling_forward(
            input,
            rois,
            output,
            argmax,
            output_size[0],
            output_size[1],
            spatial_scale)

        ctx.save_for_backward(rois, argmax)
        return output

    @staticmethod
    def backward(ctx, grad_output):
        rois, argmax = ctx.saved_tensors
        grad_input = grad_output.new_zeros(ctx.input_shape)

        imtk_qtp.roi_pooling_backward(
            grad_output,
            rois,
            argmax,
            grad_input,
            ctx.output_size[0],
            ctx.output_size[1],
            ctx.spatial_scale)

        return grad_input, None, None, None

class RoIPool(nn.Module):
    def __init__(self, output_size, spatial_scale=1.0):
        super(RoIPool, self).__init__()

        self.output_size = output_size
        self.spatial_scale = float(spatial_scale)

    def forward(self, input, rois):
        return roi_pool.apply(input, rois, self.output_size, self.spatial_scale)
